document.addEventListener('DOMContentLoaded', function() {
  // Mobile menu functionality can be added here if needed
  // For now, this is just a placeholder for any future menu functionality
}); 